## Char-RNN
Refer to [karpathy](https://github.com/karpathy/char-rnn) or [johnarevalo](https://github.com/johnarevalo/blocks-char-rnn).

