## 如何贡献代码

### 提交地址

欢迎开发者贡献简单易懂的代码和案例，请将您的代码和案例章节以一个完整文件夹的形式提PR至我们的[开发fork分支](https://github.com/DiscoverML/simplified-deeplearning)的pending文件夹中，被接收后，我们将以合适的形式将其添加至根目录的对应位置

### 推荐开发环境

1. Python3.5+
1. Tensorflow
1. Jupyter Notebook
